﻿using BaseballGame.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BaseballGame
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter input block:"); // Prompt
            string inputBlock = Console.ReadLine(); // Get string from user
            Console.WriteLine("Enter input number hits:"); // Prompt
            string numberHits = Console.ReadLine();
            List<string> hits = inputBlock.Split(',').Select(s => s.Trim()).ToList();

            if (numberHits != hits.Count.ToString())
            {
                Console.WriteLine("Number of hits is not correct, please try again.");
            }
            //using a linked list because we are adding and removing contents
            LinkedList<HitData> hitsData = new LinkedList<HitData>();
            foreach (var item in hits)
            {
                IRuleStrategy ruleStrategy = null;

                //Sorting the countyResidents
                ruleStrategy = GetRule(item);
                ruleStrategy.ApplyRule(hitsData, item);

            }

            int finalScore = hitsData.Select(x => x.CurrentScore).Sum();

            //int finalScore = CalculateScoreService.Calculate(inputBlock, numberHits);

            Console.WriteLine("Final score: " + finalScore);

            #if DEBUG
            Console.WriteLine("Press enter to close...");
            Console.ReadLine();
            #endif
        }

        private static IRuleStrategy GetRule(string hit)
        {
            IRuleStrategy ruleStrategy = null;

            if (int.TryParse(hit, out int value))
            {
                ruleStrategy = new IntegerRule();
            }
            else if (hit == "X")
            {
                ruleStrategy = new XRule();
            }
            else if (hit == "+")
            {
                ruleStrategy = new SumRule();
            }
            else if (hit == "Z")
            {
                ruleStrategy = new ZRule();
            }
            else
            {
                ruleStrategy = new EmptyRule();
            }

            return ruleStrategy;
        }

    }

    public interface IRuleStrategy
    {
        void ApplyRule(LinkedList<HitData> ruleData, string hit);
    }



    public class IntegerRule : IRuleStrategy
    {
        public void ApplyRule(LinkedList<HitData> hitsData, string hit)
        {
            hitsData.AddLast(new HitData
            {
                Symbol = hit,
                CurrentScore = int.Parse(hit)
            });
        }
    }

    public class XRule : IRuleStrategy
    {
        public void ApplyRule(LinkedList<HitData> hitsData, string hit)
        {
            var lastScore = hitsData.Last();
            int value = hitsData.Count > 0 ? hitsData.Last().CurrentScore * 2 : 0;
            hitsData.AddLast(new HitData
            {
                Symbol = hit,
                CurrentScore = value
            });
        }
    }

    public class SumRule : IRuleStrategy
    {
        public void ApplyRule(LinkedList<HitData> hitsData, string hit)
        {
            int value = hitsData.Reverse().Take(2).Select(x => x.CurrentScore).Sum();
            hitsData.AddLast(new HitData
            {
                Symbol = hit,
                CurrentScore = value
            });
        }
    }

    public class ZRule : IRuleStrategy
    {
        public void ApplyRule(LinkedList<HitData> hitsData, string hit)
        {
            if (hitsData.Count > 0)
                hitsData.RemoveLast();
        }
    }

    public class EmptyRule : IRuleStrategy
    {
        public void ApplyRule(LinkedList<HitData> hitsData, string hit)
        {
            //do nothing
        }
    }

   

    //public class CalculateScoreService
    //{


    //    public static int Calculate(string inputBlock, int numberHits)
    //    {

    //        List<string> hits = inputBlock.Split(',').ToList();

    //        //remove the brackets
    //        if (numberHits != hits.Count)
    //        {
    //            //return error
    //        }
    //        //using a linked list because we are adding and removing contents
    //        LinkedList<Score> Scores = new LinkedList<Score>();
    //        foreach (var item in hits)
    //        {
    //            //loop through each item - check first if int. 
    //            if (int.TryParse(item, out int value))
    //            {
    //                Scores.AddLast(new Score
    //                {
    //                    Symbol = item,
    //                    CurrentScore = value
    //                });

    //            }
    //            else if (item == "X")
    //            {
    //                //get the previous score and times by 2 
    //                var lastScore = Scores.Last();
    //                value = Scores.Count > 0 ? Scores.Last().CurrentScore * 2 : 0;
    //                Scores.AddLast(new Score
    //                {
    //                    Symbol = item,
    //                    CurrentScore = value 
    //                });

    //            }
    //            else if (item == "+")
    //            {
    //                //sum of last 2 scores
    //                value = Scores.Reverse().Take(2).Select(x => x.CurrentScore).Sum();
    //                Scores.AddLast(new Score
    //                {
    //                    Symbol = item,
    //                    CurrentScore = value
    //                });
    //            }
    //            else if (item == "Z")
    //            {
    //                //remove the final score
                    
    //                if(Scores.Count > 0)
    //                    Scores.RemoveLast();
    //            }
    //        }


    //        return Scores.Select(x => x.CurrentScore).Sum();

    //    }
    //}

    
}
