﻿using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ShapeTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Shape rectangle = new Rectangle(new FileLogger()) { Height = 3, Width = 2};
            Assert.AreEqual(6, rectangle.Area());

        }
    }

    public abstract class Shape
    {
        private ILogger _logger;
        

        public Shape(ILogger logger)
        {
            this._logger = logger;
        }
        public abstract int Area();
        public abstract int Perimeter();

        public void LoggMessage(string message)
        {
            _logger.LogMessage(message);
        }
    }

    public class Circle : Shape
    {
        public Circle(ILogger logger) :base(logger)
        {

        }

        private readonly double _pi = Math.PI;

        public int Radius { get; set; }

        public override int Area()
        {
            return (int)(_pi * Radius * Radius);
        }

        public override int Perimeter()
        {
            return (int)(2 * _pi * Radius);
        }
    }

    public class Rectangle : Shape
    {
        public Rectangle(ILogger logger) : base(logger)
        {

        }

        public int Height { get; set; }
        public int Width { get; set; }

        public override int Area()
        {
            return Height * Width;
        }

        public override int Perimeter()
        {
            return 2 * (Height + Width);
        }
    }

    public class Triange : Shape
    {
        public Triange(ILogger logger) : base(logger)
        {

        }


        public int SideA { get; set; }
        public int Base { get; set; }
        public int SideB { get; set; }
        public int Height { get; set; }

        public override int Area()
        {
            return (Height * Base)/2;
        }

        public override int Perimeter()
        {
            return SideA + Base + SideB;
        }
    }

    public interface ILogger
    {
        void LogMessage(string aString);
    }

    public class FileLogger : ILogger
    {
        public void LogMessage(string text)
        {
            using (StreamWriter writer = new StreamWriter("C:\\TextFile.txt"))
            {
                writer.WriteLine(text);
            }

        }
    }
}
