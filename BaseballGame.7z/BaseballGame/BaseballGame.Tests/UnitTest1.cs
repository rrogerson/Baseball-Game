﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BaseballGame.Models;
using System.Linq;
using BaseballGame2;

namespace BaseballGame.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

            string inputBlock = "5, -2, 4, Z, X, 9, +, +";
            List<string> hits = inputBlock.Split(',').Select(s => s.Trim()).ToList();
            LinkedList<HitData> hitsData = new LinkedList<HitData>();
            foreach (var item in hits)
            {
                IRuleStrategy ruleStrategy = null;

                //Sorting the countyResidents
                ruleStrategy = Strategy.GetRule(item);
                ruleStrategy.ApplyRule(hitsData, item);

            }

            int finalScore = hitsData.Select(x => x.CurrentScore).Sum();

            Assert.AreEqual(27, finalScore);

        }
    }
}
